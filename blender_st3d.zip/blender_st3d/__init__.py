﻿bl_info = {
    "name": "BlenderST3D",
    "author": "TASK Studio",
    "version": (0, 1),
    "blender": (2, 80, 0),  # Ensure this matches your Blender version
    "description": "Enables speech recognition for Blender",
    "category": "3D View",
}

# if "bpy" in locals():
#     import imp
#     imp.reload(mycube)
#     imp.reload(mysphere)
#     imp.reload(mycylinder)
#     print("Reloaded multifiles")
# else:
#     print("Imported multifiles")

import bpy


def register():
    print("Registering ", __name__)
    bpy.utils.register_module(__name__)


def unregister():
    print("Unregistering ", __name__)
    bpy.utils.unregister_module(__name__)


if __name__ == "__main__":
    register()
